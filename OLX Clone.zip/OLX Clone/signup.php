<?php
include 'includes/connection.php';

?>
<html>
    <head>
        <title>signup</title>
        <link rel="stylesheet" href="CSS/admin.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="mx-auto mt-3">
                <div class="lgn">
                    <div class="card">
                        <div class="card-body">
                        <div class="col-sm">
           <h3 class="text-center">ExchangeHub</h3>
        </div>
            <h5>Free Signup It's Easy</h5>
            <form class="form-group" id="frm">
                <div class="form-group">
                    <label>First Name</label><br>
                    <input type="text" name="fname" id="fn" placeholder="Enter First Name" class="form-control">
                </div>
                <div class="form-group">
                    <label>Last Name</label><br>
                    <input type="text" name="lname" id="ln" placeholder="Enter Last Name" class="form-control">
                </div>
                <div class="form-group">
                    <label>Email Id</label><br>
                    <input type="email" name="email" id="email" placeholder="Enter email" class="form-control">
                </div>
                <div class="form-group">
                <label>Password</label><br>
                    <input type="password" name="pass" id="pass" placeholder="Enter Password" class="form-control">
                </div>
                <div class="form-group">
                    <label>Confirm Password</label><br>
                    <input type="password" name="cpass" id="cpass" placeholder="Confirm password" class="form-control">
                </div>
                <input type="button" name="submit" value="submit" id="submit" class="btn btn-success">
                <div id="response"></div>
                <div class="footer">
            <p>Already have an account? <a href="#">Login here</a></p>
        </div>
            </form>
            </div>
            </div>
            </div>
        </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        $("#submit").click(function(){
            var ufname=$("#fn").val();
            var ulname=$("#ln").val();
            var email=$("#email").val();
            var password=$("#pass").val();
            var cpassword=$("#cpass").val();
            if(ufname=="" || ulname=="" || email=="" || password=="" || cpassword ==""){
                $("#response").fadeIn();
                $("#response").html("All fields should be filled.");
                setTimeout(function(){
                    $('#response').fadeOut("slow");
                }, 4000);
                if(password != cpassword){
                $("#response").fadeIn();
                $("#response").html("Confirm password");
                setTimeout(function(){
                    $('#response').fadeOut("slow");
                }, 4000);
            }
        }
            else{
                $.ajax({
                    url:"usign.php",
                    type:"POST",
                    data:$("#frm").serialize(),
                    success:function(data)
                    {
                        $('#response').trigger("reset");
                        $('#response').fadeIn();
                        $('#response').html(data);
                        setTimeout(function(){
                            $('#response').fadeOut("slow");
                        }, 4000);
                        
                    }
                });
            }
        });
    });
</script>
<!--<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>-->
</body>
</html>