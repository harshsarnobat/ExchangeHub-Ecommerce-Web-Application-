<?php
session_start();
include 'includes/connection.php';

$user = '';
    
// Check if the session variable 'email1' is set
if (isset($_SESSION['email1'])) {
    // Query to get user info from the database based on email
    $qry = "SELECT * FROM users WHERE email = '$_SESSION[email1]'";
    $res = mysqli_query($conn, $qry);
    
    // If the query returns a valid result, fetch the user's name
    if ($res && mysqli_num_rows($res) > 0) {
        $data = mysqli_fetch_array($res);
        $user = $data['fname'];  // Store the user's first name
    } 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ExchangeHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <!-- Bootstrap CSS -->
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link href="CSS/style.css" rel="stylesheet"/>
    <link href="CSS/user.css" rel="stylesheet"/>
    <style>
        /* Flexbox layout for the header section */
        #header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        /* Styling for the user info and settings to align inline */
        .user-settings {
            display: flex;
            align-items: center;
        }
        /* Styling for the dropdown */
        .dropdown {
            position: relative;
            display: inline-block;
            margin-left: 10px; /* Space between user name and dropdown */
        }
        .dropdown-menu {
            position: absolute; 
            min-width: 150px; /* Adjust width of the dropdown */
            padding: 5px 10px; /* Optional: Adjust padding */
            font-size: 14px; /* Optional: Adjust font size */
            top: 100%; /* Dropdown appears below the toggle button */
            left: 0; /* Aligns the dropdown to the left of the button */
            z-index: 9999; /* Ensure dropdown is above other elements */
        }
        .dropdown-toggle {
            cursor: pointer;
        }
        td.bold-text {
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row align-items-center" id="header" style="background-color: rgb(186, 235, 255);">
        <!-- Logo Section -->
        <div class="col-sm-2">
            <h5 class="l mt-3"><i class="fas fa-shipping-fast fa-flip-horizontal"></i>ExchangeHub</h5>
        </div>
        
        <!-- Category Dropdown -->
        <div class="col-md-2 mt-3">
            <div class="form-group">
                <select class="form-control">
                    <option>Select Category</option>
                    <?php
                                    $qry="SELECT * FROM category WHERE pid='0'";
                                    $exe=mysqli_query($conn,$qry);
                                    while($data=mysqli_fetch_array($exe)){
                                        $id=$data["id"];
                                        $name=$data["title"];
                                        ?>
                                        <option value="<?php echo $id;?>"><?php echo $name;?></option>
                                        <?php
                                    }
                                    ?>
                </select>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="col-md-5 mt-3">
            <form class="form-group">
                <input type="text" name="search" class="form-control" placeholder="Search what do you need..">
            </form>
        </div>

        <div class="col-md-3 mt-2  user-settings">
        <!-- Navigation Icons -->
                    <?php
                     if(isset($_SESSION['email1'])){

                        ?>
                        <span class="ml"><i class="fas fa-user"></i> <?php echo $user;?></span>

                        <div class="dropdown ml">
                            <span class="dropdown-toggle ml" data-toggle="dropdown"><i class="fas fa-cog"></i> Settings</span>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href=""><i class="fas fa-ad"></i> My Ads</a>
                                <a class="dropdown-item" href=""><i class="fas fa-user-circle"></i> Profile</a>
                                <a class="dropdown-item" href="addlist.php"><i class="fas fa-ad"></i> Add Ads</a>
                                <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-in-alt"></i> Logout</a>
                     </div>
                     </div>

                        <?php
                     }
                     else{
                        ?>
                         <span class="ml"><i class="fas fa-user"></i>User |</span>
                        <a href="ulogin.php"><span class="ml"><i class="fas fa-sign-in-alt"></i> Signin | </span></a>
                        <a href="signup.php"><span class="ml"><i class="fas fa-user-plus"></i> Signup</span></a>
                        <?php
                     }
                     
                     ?>
        </div>
        <div class="main-menu">
            <button type="button" class="btn btn" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">Show All</button>
                     <?php
                     include 'includes/connection.php';

                     $qry="SELECT * FROM category WHERE pid='0'";
                                    $exe=mysqli_query($conn,$qry);
                                    while($data=mysqli_fetch_array($exe)){
                                        $id=$data["id"];
                                        $name=$data["title"];
                                         ?>
                                         <ul>
                                            <li>
                                                <?php echo "<a href='deatil.php?id=$id'>"."$name</a>"?>
                                            </li>
                                         </ul>
                                        <?php

                                    }
                     ?>
    </div>
    
    </div>
    <div class="collapse" id="collapseExample">
            <div class="card card-body">
                                <div class="row">
                    <div class="col-sm-3 ml-3"  style="white-space: nowrap; display: inline;">
                        <?php
                        include 'includes/connection.php';
                        $qrymbl="select * from category where title='Electronics'";
                        $mblres=mysqli_query($conn,$qrymbl);
                        while($mblrow=mysqli_fetch_array($mblres)){
                            $mblid=$mblrow["id"];
                            $mbtitle=$mblrow["title"];
                            ?>
                            <h6><?php echo $mbtitle; ?></h6>
                            <?php
                            $mbld="select * from category where pid='$mblid'";
                            $mres=mysqli_query($conn,$mbld);
                            while($mrow=mysqli_fetch_array($mres)){
                                    $mid=$mrow["id"];
                                    $mmbl=$mrow["title"];
                                    ?>
                                    <span><?php echo $mmbl."<br>";?></span>
                                    <?php
                            }
                            ?>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="col-sm-3 ml-3"  style="white-space: nowrap; display: inline;">
                        <?php
                        include 'includes/connection.php';
                        $qrymbl="select * from category where title='Furniture'";
                        $mblres=mysqli_query($conn,$qrymbl);
                        while($mblrow=mysqli_fetch_array($mblres)){
                            $mblid=$mblrow["id"];
                            $mbtitle=$mblrow["title"];
                            ?>
                            <h6><?php echo $mbtitle; ?></h6>
                            <?php
                            $mbld="select * from category where pid='$mblid'";
                            $mres=mysqli_query($conn,$mbld);
                            while($mrow=mysqli_fetch_array($mres)){
                                    $mid=$mrow["id"];
                                    $mmbl=$mrow["title"];
                                    ?>
                                    <span><?php echo $mmbl."<br>";?></span>
                                    <?php
                            }
                            ?>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="col-sm-3 ml-3"  style="white-space: nowrap; display: inline;">
                        <?php
                        include 'includes/connection.php';
                        $qrymbl="select * from category where title='Vehicles'";
                        $mblres=mysqli_query($conn,$qrymbl);
                        while($mblrow=mysqli_fetch_array($mblres)){
                            $mblid=$mblrow["id"];
                            $mbtitle=$mblrow["title"];
                            ?>
                            <h6><?php echo $mbtitle; ?></h6>
                            <?php
                            $mbld="select * from category where pid='$mblid'";
                            $mres=mysqli_query($conn,$mbld);
                            while($mrow=mysqli_fetch_array($mres)){
                                    $mid=$mrow["id"];
                                    $mmbl=$mrow["title"];
                                    ?>
                                    <span><?php echo $mmbl."<br>";?></span>
                                    <?php
                            }
                            ?>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
    </div>

   
    
<table class="table table-bordered" cellspacing=0 cellpading=10>
<tr class="bg-primary text-white">
    <th>Product Name</th>
    <th>Price</th>
    <th>Image</th>
    <th>Shop</th>
</tr>
<?php
$i=1;
$rows=mysqli_query($conn,'SELECT name,price,file FROM ad ORDER BY id DESC')
?>
<?php foreach($rows as $row):?>
<tr>
    <td><h4><?php echo $row['name']; ?></h4></td>
    <td><h4><?php echo '₹',$row['price']; ?></h4></td>
    <td><img src="upload/<?php echo $row['file']?>" width=200 alt=""></td>
    <td><button class="btn btn-success" onclick="mess()" enabled>Add to cart</button><br></td>
</tr>
<?php endforeach;?>
</table>
        </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script>
    function mess(){
        alert('Your product is added to cart.');
    }
</script>
</body>
</html>
