<?php
session_start();
include 'includes/connection.php';

if(isset($_POST["submit"])){
    $name = $_POST["name"];
    $pid = $_POST["pid"];
    $price = $_POST["price"];
    $address = $_POST["address"];
    $address1 = $_POST["address1"];
    $pincode = $_POST["pin"];
    
    if($_FILES["image"]["error"] === 4){
        echo "<script>alert('Image does not exist');</script>";
    }
    else{
        $fileName = $_FILES["image"]["name"];
        $fileSize = $_FILES["image"]["size"];
        $tmpName = $_FILES["image"]["tmp_name"];

        // Valid image extensions
        $validImgExtensions = ['jpg', 'jpeg', 'png'];
        $imageExtension = explode('.', $fileName);
        $imageExtension = strtolower(end($imageExtension));

        if(!in_array($imageExtension, $validImgExtensions)){
            echo "<script>alert('Invalid file type');</script>";
        }
        else if($fileSize > 99999999){
            echo "<script>alert('File is too large');</script>";
        }
        else{
            // Generate a unique name for the image
            $newImgName = uniqid() . '.' . $imageExtension;
            
            // Specify the correct path for the upload
            $uploadPath = 'upload/' . $newImgName;

            // Move the file to the upload directory
            if(move_uploaded_file($tmpName, $uploadPath)){
                // Insert the data into the database
                $query = "INSERT INTO ad (id,name,pid,price,address,address1,pincode,file) VALUES ('','$name', '$pid','$price','$address','$address1','$pincode','$newImgName')";
                
                // Check if the query was successful
                if(mysqli_query($conn, $query)){
                    echo "<script>alert('Successful.');
                    document.location.href='index.php';
                    </script>";
                } else {
                    echo "<script>alert('Database error: " . mysqli_error($conn) . "');</script>";
                }
            } else {
                echo "<script>alert('Failed to upload the image');</script>";
            }
        }
    }
}
?>
<html>
<title>POST ADS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<!-- Custom CSS -->
<style>
    .form-control {
        width: 100%; /* Ensure it stretches to the full width of its container */
    }

    .col-sm-8, .col-sm-4 {
        margin-top: 20px;
    }

</style>

<body>
<div class="container">
    <div class="row">
        <!-- Form Section -->
        <div class="col-sm-8">
            <div class="card">
                <div id="res"></div>
                <div class="card-body">
                    <div class="card-title text-center">
                        <h4>Add Your Ads.</h4>
                    </div>
                    <form class="form-group" id="lfrm" method="post" enctype="multipart/form-data"><br>
                        <div class="form-group">
                            <input type="text" id="name" class="form-control" name="name" placeholder="Enter Ad name." required>
                        </div>

                        <div class="form-group">
                            <select class="form-control" name="pid" id="ctid">
                                <option value="0">Add as main</option>
                                <?php
                                $qry = "SELECT * FROM category";
                                $exe = mysqli_query($conn, $qry);
                                while ($data = mysqli_fetch_array($exe)) {
                                    $id = $data["id"];
                                    $name = $data["title"];
                                    ?>
                                    <option value="<?php echo $id; ?>">
                                        <?php echo $name; ?>
                                    </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <input type="text" id="price" name="price" class="form-control" placeholder="Price" required>
                        </div>

                        <div class="form-group">
                            <input type="text" id="address" name="address" placeholder="State" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input type="text" id="address1" name="address1" placeholder="City" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input type="text" id="pin" name="pin" placeholder="Pincode" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input type="file" id="image" name="image" required>
                        </div>

                        <input type="submit" value="Submit" id="submit" onclick="mess()" class="btn btn-primary" name="submit">
                    </form>
                </div>
            </div>
        </div>

        <!-- Instructions Section -->
        <div class="col-sm-4 rm-2">
            <div class="card">
                <div class="card-header text-center">
                    <h4>Instructions</h4>
                </div>
                <div class="card-body">
                    <blockquote class="blockquote mb-0">
                        <h5>Welcome to ExchangeHub!<br></h5>
                        <p style="color:red;">- To post your ad, please fill out the form.</p>
                        <p style="color:red;">- Once you're done, click 'Submit' to post your ad. Thank you for choosing ExchangeHub!</p>
                    </blockquote>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
<script>
    function mess(){
        alert('Your product is added to cart.');
    }
    </script>
</html>
