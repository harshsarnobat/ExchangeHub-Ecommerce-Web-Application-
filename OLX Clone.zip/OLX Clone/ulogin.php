<?php
include 'includes/connection.php';
session_start();
if(isset($_SESSION['email1'])){
    header("location:index.php");
}
?>
<?php
if(isset($_POST['login'])){
    $qry="SELECT * FROM users WHERE email='$_POST[email]'";
    $result=mysqli_query($conn,$qry);
    if(mysqli_num_rows($result)>0){
        while ($row=mysqli_fetch_array($result)) {
            if ($_POST["email"]==$row["email"] && $_POST["password"]==$row["upassword"]) {
                $_SESSION['email1']=$_POST['email'];
                header("location:index.php");
            }
            else {
                $msg="invalid Email or Password";
            }
        }
    }
}
?>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="CSS/admin.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="mx-auto mt-5">
                <div class="lgn">
                    <div class="card">
                        <div class="card-body">
            <h3 class="text-center ">ExchangeHub</h3>
            <?php if(isset($msg)){ ?>
            <span class="nagitive" id="ms"><?php echo "$msg";}?></span>
            <form class="form-group" action="#" method="post">
                <div class="form-group">
                    <label>Username</label><br>
                    <input type="email" name="email" placeholder="Enter Email" class="form-control" required>
                </div>
                <div class="form-group">
                <label>Password</label><br>
                    <input type="password" id="password" name="password" placeholder="Enter Password" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="checkbox" onclick="show()">
                    <label>Show Password</label>
                </div>
                <div class="form-group">
                    <center><input type="submit" name="login" placeholder="Submit" class="btn btn-primary"></center>
                </div>
                <center><a href="fpass.php">Forgot password.</a></center>
            </form>
            </div>
            </div>
            </div>
        </div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
     $(document).ready(function(){
        setTimeout(function(){
            $('#ms').fadeOut("slow");
        }, 4000);
    });
</script>
<script type="text/javascript">
    function show() {

const passwordInput = document.getElementById('password');
if(passwordInput.type==="password"){
passwordInput.type="text";
}
else{
passwordInput.type="password";
}

}
</script>
</body>
</html>