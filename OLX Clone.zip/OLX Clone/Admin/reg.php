<?php
include 'include/connection.php';
$user=$_POST["name"];
$email=$_POST["email"];
$password=$_POST["password"];
$qry="INSERT INTO reg(user,email,password)VALUES('$user','$email','$password')";
$result=mysqli_query($conn,$qry);
if($result){
    echo "Hello {$user} your record has been saved.";
}
else{
    echo "Can't saved";
}
?>