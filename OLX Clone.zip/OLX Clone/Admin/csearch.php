<?php
session_start();
if (!isset($_SESSION['email1'])) {
    header("location:index.php?msg=Please Login");
    exit();
}

include 'include/connection.php';
$search = $_POST['search'] ?? '';

// Query to search in the `category` table for titles matching the search term
$qry = "SELECT * FROM category WHERE title LIKE '%$search%'";
$exe = mysqli_query($conn, $qry);
$sr = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link rel="stylesheet" href="path/to/your/css/styles.css">
</head>
<body>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Sr No.</th>
            <th>Title</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($data = mysqli_fetch_array($exe)): ?>
            <?php
            $id = $data['id'];
            $title = $data['title'];
            $status = isset($data['status']) ? $data['status'] : 0;
            $sr++;
            ?>
            <tr>
                <td><?php echo $sr; ?></td>
                <td><?php echo htmlspecialchars($title); ?></td>
                <td>
                    <?php if ($status == 1): ?>
                        <button class="btn btn-danger" disabled>Disable</button>
                    <?php else: ?>
                        <button class="btn btn-success" disabled>Enable</button>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="editcat.php?id=<?php echo $id; ?>" style="margin:10px;">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a href="deletecat.php?id=<?php echo $id; ?>" style="margin:10px;">
                        <i class="fas fa-trash"></i>
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>
