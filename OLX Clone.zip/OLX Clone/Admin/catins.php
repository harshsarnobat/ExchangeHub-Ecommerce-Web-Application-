<?php
include 'include/connection.php';
$title=$_POST["title"];
$status=$_POST["status"];
$description=$_POST["desc"];
$qry="INSERT INTO category(title,cstatus,cdesc,pid)VALUES('$title','$status','$description','$_POST[pid]')";
$result=mysqli_query($conn,$qry);
if($result){
    echo "Category inserted";
}
else{
    echo "Category not inserted";
}
?>