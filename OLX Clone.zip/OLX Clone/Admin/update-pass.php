<?php
session_start();
include 'include/connection.php';
$query="UPDATE reg SET password='$_POST[cpass]' WHERE email='$_SESSION[email1]'";
$res=mysqli_query($conn,$query);
if($res){
    echo "Your password has been updateded sucessfully.";
}
?>