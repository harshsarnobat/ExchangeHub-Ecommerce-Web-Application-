<?php
include 'include/connection.php';
$delelet_id=$_GET['id'];
$query="DELETE FROM category WHERE id='$delelet_id'";
$res=mysqli_query($conn,$query);
if($res){
    header("location:addcat.php");
    
}
else{
    echo"Not delete";
}
?>