<?php
session_start();
if(!isset($_SESSION['email1'])){
    header("location:index.php?msg=Plz Login");
}
?>
<style></style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ExchangeHub</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link href="CSS/style.css" rel="stylesheet"/>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <?php
include 'include/sidebar.php';
?>

        <!-- Page Content -->
        <div id="content">
                <?php
                include 'include/nav.php';
                ?>
        <dic class="container">
        <center><h2>ExchangeHub</h2></center>
        <p>ExchangeHub is a modern marketplace platform designed to connect buyers and sellers
            , much like OLX. However, as the admin of an OLX clone platform like ExchangeHub, you have a crucial role in ensuring that the platform runs smoothly, securely, and offers a positive experience for both users. This blog will outline the key responsibilities of the admin and how they can manage and optimize the platform efficiently.
            Being the admin of an OLX clone like ExchangeHub requires dedication, attention to detail, and constant monitoring of platform activities. By keeping user accounts, transactions, and listings secure, and ensuring continuous improvement through data and user feedback, you can create a trustworthy and thriving marketplace. A well-managed platform will attract users, generate revenue, and build a loyal community.
Remember, your role as the admin is vital in making ExchangeHub the go-to marketplace for both buyers and sellers.</p>
    </div>
            
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="JS/script.js"></script>
</body>
</html>
