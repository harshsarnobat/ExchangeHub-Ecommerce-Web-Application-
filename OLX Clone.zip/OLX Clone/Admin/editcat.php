<?php
include 'include/connection.php';
session_start();
if(!isset($_SESSION['email1'])){
    header("location:index.php?msg=Plz Login");
}
?>
<?php
$edit_id=$_GET["id"];
if(isset($_POST["submit"])){
    $update="UPDATE category SET title='$_POST[title]',cstatus='$_POST[status]',cdesc='$_POST[desc]' WHERE id='$edit_id'";
    $exe=mysqli_query($conn,$update);
    if($exe){
    header("location:addcat.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Categories</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link href="CSS/style.css" rel="stylesheet"/>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <?php
include 'include/sidebar.php';
?>

        <!-- Page Content -->
        <div id="content">
                <?php
                include 'include/nav.php';
                ?>
                <div class="container">
                    <div class="row">
                        <div class="mx-auto mt-2.5">
                        <div class="card" >
                        <div class="card-header bg-primary">
                        <h3 class="text-center text-white">Edit Category</h3>
                        </div>
                        <div class="card-body">
                        <?php

                            $delelet_id=$_GET['id'];
                            $query="SELECT * FROM category WHERE id='$edit_id'";
                            $res=mysqli_query($conn,$query);
                            $data=mysqli_fetch_array($res);
                            $ctitle=$data["title"];
                            $cstatus=$data["cstatus"];
                            $cdesc=$data["cdesc"];
                            ?>
                        <form class="form-group" action="#" method="post">
                            <div class="form-group">
                            <input type="text" name="title" class="form-control" value="<?php echo $ctitle;?>"/>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="status" id="status">
                                    <option value="">Choose Status</option>
                                    <option value="1">Enabled</option>
                                    <option value="0">Disabled</option>
                                    
                                </select>
                                
                            </div>
                            <div class="form-group">
                            <input type="text" name="desc" class="form-control" value="<?php echo $cdesc;?>" id="desc-t" style="height:100px;"/> 
                            </div>
                            <div class="form-group">
                                <input type="submit" id="submit" name="submit" value="submit" class="btn btn-primary"> 
                            </div>
                            </form>
                            </div>
                    </div>
                </div>
                <!--category fetching-->
               
           
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <!--<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>-->
    <script type="text/javascript" src="JS/script.js"></script>
</body>
</html>
