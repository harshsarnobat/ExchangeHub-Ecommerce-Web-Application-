<?php
$conn=new mysqli("localhost","root","","olxclone");
?>