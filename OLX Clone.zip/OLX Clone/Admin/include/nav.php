 <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        Hide/View Menu
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <?php
                            //session_start();
                            include 'include/connection.php';
                            $qry="select * from reg where email='$_SESSION[email1]'";
                            $res=mysqli_query($conn,$qry);
                            $data=mysqli_fetch_array($res);
                            $user=$data['user'];
                            ?>
                            <li class="nav-item active"><a class="nav-link" href="#" style="color: #7386D5;">Welcome <?php echo $user;?></a></li>
                            <li class="nav-item active"><a class="nav-link" href="home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
