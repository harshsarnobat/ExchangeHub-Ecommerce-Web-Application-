
<nav id="sidebar">
            <div class="sidebar-header">
                <h3>ExchangeHub</h3>
            </div>
            <ul class="list-unstyled components">
                <li><a href="admin_profile.php"><img src="images/user.png" alt="Logout" style="width: 20px; height: 20px; margin-right: 8px;">Profile</a></li>
                <li><a href="addcat.php"><img src="images/cat.png" style="width: 20px; height: 20px; margin-right: 8px;">Add Category</a></li>
                <li><a href="#"><img src="images/options-lines.png"style="width: 20px; height: 20px; margin-right: 8px;">Show Listening</a></li>
                <li><a href="#"><img src="images/users.png"style="width: 20px; height: 20px; margin-right: 8px;">User</a></li>
                <li><a href="#"><img src="images/feed.png" alt="Logout" style="width: 20px; height: 20px; margin-right: 8px;">Feedback</a></li>
                <li><a href="logout.php"><img src="images/logout.png" alt="Logout" style="width: 20px; height: 20px; margin-right: 8px;">Logout</a></li>
            </ul>
        </nav>
