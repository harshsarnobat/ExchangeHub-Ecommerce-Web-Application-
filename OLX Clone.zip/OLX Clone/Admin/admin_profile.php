<?php
session_start();
if (!isset($_SESSION['email1'])) {
    header("location:index.php?msg=Please Login");
}
?>
<?php 
include 'include/connection.php';
$qry="SELECT * FROM reg WHERE email='$_SESSION[email1]'";
$exe=mysqli_query($conn,$qry);
$data=mysqli_fetch_array($exe);
$pas=$data["password"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Categories</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link href="CSS/style.css" rel="stylesheet"/>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <?php
include 'include/sidebar.php';
?>

        <!-- Page Content -->
        <div id="content">
                <?php
                include 'include/nav.php';
                ?>
                                <div class="container">
                    <div class="row">
                        <div class="cols-sm-8 mt-2.5 ml-3">
                        <div class="card" >
                        <div class="card-header bg-primary">
                        <h3 class="text-center text-white">Update My Profile</h3>
                        </div>
                        <div class="card-body">
                        <form class="form-group" id="frm">
                            <div class="form-group">
                            <input type="text" name="pass" id="pass" placeholder="Old Password" value="<?php echo $pas;
                            ?>" class="form-control"/>
                            </div>
                            <div class="form-group">
                            <input type="password" name="cpass" id="cpass" placeholder="Enter New Password" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <input type="button" id="submit" name="updatepass" value="Change" class="btn btn-primary"> 
                            </div>
                            <div id="response"></div>
                    </div>
</div>
</div>
</div>
</div>

        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!--<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>-->
    <script type="text/javascript" src="JS/script.js"></script>
    <script>
         $(document).ready(function(){
        $("#submit").click(function(event){
            event.preventDefault(); 
            var cpas=$("#cpass").val();
           
            if(cpas==""){
                $("#response").fadeIn();
                $("#response").html("Field should be filled.");
                setTimeout(function(){
                    $('#response').fadeOut("slow");
                }, 4000);
            }
            else{
                $.ajax({
                    url:"update-pass.php",
                    type:"POST",
                    data:$("#frm").serialize(),
                    success:function(data)
                    {
                        $('#response').trigger("reset");
                        $('#response').fadeIn();
                        $('#response').html(data);
                        setTimeout(function(){
                            $('#response').fadeOut("slow");
                        }, 4000);
                        
                    }
                });
            }
        });
    });
                
    </script>
</body>
</html>

