<html>
    <head>
        <title>Admin Login</title>
        <link rel="stylesheet" href="CSS/admin.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="mx-auto mt-5">
                <div class="lgn">
                    <div class="card">
                        <div class="card-body">
            <h3 class="alert alert-success">Admin Signup</h3>
            <form class="form-group" id="frm">
                <div class="form-group">
                    <label>Name</label><br>
                    <input type="text" name="name" id="name" placeholder="Enter Name" class="form-control">
                </div>
                <div class="form-group">
                    <label>Email Id</label><br>
                    <input type="email" name="email" id="email" placeholder="Enter email" class="form-control">
                </div>
                <div class="form-group">
                <label>Password</label><br>
                    <input type="password" name="password" id="password" placeholder="Enter Password" class="form-control">
                </div>
                <input type="button" name="submit" value="submit" id="submit" class="btn btn-success">
                <div id="response">

                </div>
            </form>
            </div>
            </div>
            </div>
        </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        $("#submit").click(function(){
            var name=$("#name").val();
            var email=$("#email").val();
            var password=$("#password").val();
            if(name=="" || email=="" || password==""){
                $("#response").fadeIn();
                $("#response").html("All fields should be filled.");
                setTimeout(function(){
                    $('#response').fadeOut("slow");
                }, 4000);
            }
            else{
                $.ajax({
                    url:"reg.php",
                    type:"POST",
                    data:$("#frm").serialize(),
                    success:function(data)
                    {
                        $('#response').trigger("reset");
                        $('#response').fadeIn();
                        $('#response').html(data);
                        setTimeout(function(){
                            $('#response').fadeOut("slow");
                        }, 4000);
                        
                    }
                });
            }
        });
    });
</script>
<!--<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>-->
</body>
</html>