<?php
session_start();
if(!isset($_SESSION['email1'])){
    header("location:index.php?msg=Plz Login");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Categories</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link href="CSS/style.css" rel="stylesheet"/>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <?php
include 'include/sidebar.php';
?>

        <!-- Page Content -->
        <div id="content">
                <?php
                include 'include/nav.php';
                ?>
                <div class="container">
                    <div class="row">
                        <div class="cols-sm-8 mt-2.5 ml-3">
                        <div class="card" >
                        <div class="card-header bg-primary">
                        <h3 class="text-center text-white">Add Category</h3>
                        </div>
                        <div class="card-body">
                        <form class="form-group" id="frm">
                            <div class="form-group">
                            <input type="text" name="title" id="ctitle" placeholder="Enter category name" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="pid" id="ctid">
                                <option value="0">Add as main</option>
                                    <?php
                                    $qry="SELECT * FROM category";
                                    $exe=mysqli_query($conn,$qry);
                                    while($data=mysqli_fetch_array($exe)){
                                        $id=$data["id"];
                                        $name=$data["title"];
                                        ?>
                                        <option value="<?php echo $id;?>">
                                            <?php echo $name;?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                                </div>
                            <div class="form-group">
                                <select class="form-control" name="status" id="status">
                                    <option value="">Choose Status</option>
                                    <option value="1">Enabled</option>
                                    <option value="0">Disabled</option>
                                    
                                </select>
                                
                            </div>
                            <div class="form-group">
                                <textarea cols="30" rows="7" name="desc" id="cdesc"></textarea>
                            </div>
                            <div class="form-group">
                                <input type="submit" id="submit" name="submit" value="submit" class="btn btn-primary"> 
                            </div>
                            <div id="response">

                            </div>
                            </form>
                            </div>
                    </div>
                </div>
                <!--category fetching-->
                <div class="cols-sm-6 mt-2.5 ml-5  w-50">
                <h1 class="text-center">Find What You Need</h1>
        <div class="search-bar text-center mb-4">
            <input type="text" class="form-control w-50 d-inline"  name="search" placeholder="Search for items..." id="srch">
                                </div>


                    <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="text-center text-white">Available Categories</h3>
                        </div>
                        <div id="table-search">

                        </div>
                        <div class="card-body">
                    <?php
                    $ftch="select * from category";
                    $exe=mysqli_query($conn,$ftch);
                    $sr=0;
                    ?>
                    <table class="table table-bordered">
                        <tr class="bg-primary text-white">
                            <th>Sr No.</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Attribute</th>
                        </tr>
                    
                    <?php
                    while($row=mysqli_fetch_array($exe))
                    {
                        $id=$row['id'];
                        $title=$row['title'];
                        $status=$row['cstatus'];
                        $desc=$row['cdesc'];
                        $sr++;
                        ?>
                    <tr>
                        <td><?php echo$sr;?></td>
                        <td><?php echo$title;?></td>
                        <td><?php
                        if($status==1){
                            ?>
                            <button class="btn btn-success" enabled>Enable</button>
                            <?php
                        }
                        else{
                            ?>
                            <button class="btn btn-danger" disabled>Disable</button>
                            <?php
                        }
                        
                        ?></td>
                        <td>
                            <?php echo "
                            <a href='editcat.php?id=$id'><i class='fas fa-edit' style='color:blue; padding:5px;'></i>";
                            ?></a>

                             <?php echo "
                            <a href='deletecat.php?id=$id'>
                            <i class='fas fa-trash-alt' style='color:blue;'></i>";?>
                            </a>
                            <?php echo "
                            <a href='addpic.php?id=$id'>
                            <i class='fas fa-photo' style='color:blue;'></i>";?>
                            </a>
                        </td>
                    </tr>
                    <?php
                    }
                ?>
                </table>
                </div>
                </div>
                <!--closing -->
                </div>
                </div>
            </div>
           
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!--<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>-->
    <script type="text/javascript" src="JS/script.js"></script>
    <script>
         $(document).ready(function(){
        $("#submit").click(function(event){
            event.preventDefault();
            var c_title=$("#ctitle").val();
            var c_status=$("#status").val();
            var c_cat=$("#ctid").val();
            var c_desc=$("#cdesc").val();
           
            if(c_title=="" || c_status=="" || c_cat=="" || c_desc==""){
                $("#response").fadeIn();
                $("#response").html("All fields should be filled.");
                setTimeout(function(){
                    $('#response').fadeOut("slow");
                }, 4000);
            }
            else{
                $.ajax({
                    url:"catins.php",
                    type:"POST",
                    data:$("#frm").serialize(),
                    success:function(data)
                    {
                        $('#response').trigger("reset");
                        $('#response').fadeIn();
                        $('#response').html(data);
                        setTimeout(function(){
                            $('#response').fadeOut("slow");
                        }, 4000);
                        
                    }
                });
            }
        });
    });
                
    </script>

    <script>
        $(document).ready(function(){
            $("#srch").on('keyup',function(){
                var search_term=$(this).val();
                $.ajax({
                        url:"csearch.php",
                        type:"POST",
                        data:{search:search_term},
                        success:function(data)
                        {
                            $('#table-search').html(data);
                        }
                });
            });
        });
    </script>
</body>
</html>
