<?php
include 'includes/connection.php';


$qry1="SELECT * FROM users WHERE email='$_POST[email]'";
$exe=mysqli_query($conn,$qry1);

if(mysqli_num_rows($exe)>0)
{
    while($row=mysqli_fetch_array($exe)){
        if($row['email']=$_POST['email']){
            echo "This Email ID already exists.";
        }
    }
}else{
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$email=$_POST["email"];
$pass=$_POST["pass"];
$cpass=$_POST["cpass"];
$qry="INSERT INTO users(fname,lname,email,upassword,cpassword)VALUES('$fname','$lname','$email','$pass','$cpass')";
$result=mysqli_query($conn,$qry);
if($result){
    echo "Hello,{$fname} your record has been saved.";
}
else{
    echo "Can't saved";
}
}
?>


